<?php if ( ! defined('ABSPATH')) exit; ?>


<div class="wrap">

	<p>Olá, <br>
	Se você está visualizando esta página, seu sistema PHP com padrão MVC está funcionando.</p>

	<p>Não deixe de visitar nosso site para dicas <a href="http://www.tutsup.com">tutsup.com</a>.

</div> <!-- .wrap -->