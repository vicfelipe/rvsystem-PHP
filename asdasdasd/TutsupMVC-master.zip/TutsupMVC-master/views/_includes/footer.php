<?php if ( ! defined('ABSPATH')) exit; ?>

</div> <!-- .main-page (header.php) -->

</body>
</html>
